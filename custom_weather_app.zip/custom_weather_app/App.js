// I would like to use keyboard type as "numeric", but for IOS if the keyboard type is numeric, negative numbers cannot be inputted. Because of this, you can input letters and symbols that aren't allowed, but it will not crash the app, it just won't allow the user to get data.
// I used humidity1, humidity2, etc. for each day because I couldn't figure out how to get a for loop for each data value I needed to save. Although this isn't optimal it does work properly.
// The problem with the 5 day tempature is that it will tell you what the temp will be exactly 24 hours later for the next day. This can be a problem because if you check the weather at midnight, the 5 day will give you the temps at midnight for the next 5 days, even if you might want the temp in the morning.
// This is my weather app. The starting screen allows the user to enter either lat and lon or a zip code. If the user elects to enter a zip code they must press use Zip Code, then, whether you inputted lat or lon, you press get weather and it will result in the weather. Once the get Weather button is pressed, all of the "Input Location" tags will be replaced with actual values. The big opening between the current temp and the current info is also replaced with an icon of the current weather. At the bottom is a horiztonal scroll bar that allows the user to see the tempature, wind speed, weather description and humidity for the next 5 days. 

import React, { useState, useEffect, useRef } from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  Image,
  ImageBackground,
  Dimensions,
} from 'react-native';
import ReactNativeAN from 'react-native-alarm-notification';
import SelectDropdown from 'react-native-select-dropdown';
// https://github.com/AdelRedaa97/react-native-select-dropdown/blob/master/examples/demo1.js
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

export default function App() {
  const [image, setImage] = useState(
    require('./assets/backgroundWeatherApp.jpg')
  );
  const [temp, setTemp] = useState('');
  const [location, setLocation] = useState('Unknown');
  const [lat, setLat] = useState('');
  const [lon, setLon] = useState('');
  const [humidity, setHumidity] = useState('');
  const [windSpeed, setWindSpeed] = useState('');
  const [humidity1, setHumidity1] = useState('');
  const [windSpeed1, setWindSpeed1] = useState('');
  const [humidity2, setHumidity2] = useState('');
  const [windSpeed2, setWindSpeed2] = useState('');
  const [humidity3, setHumidity3] = useState('');
  const [windSpeed3, setWindSpeed3] = useState('');
  const [humidity4, setHumidity4] = useState('');
  const [windSpeed4, setWindSpeed4] = useState('');
  const [humidity5, setHumidity5] = useState('');
  const [windSpeed5, setWindSpeed5] = useState('');
  const [feelsLike, setFeelsLike] = useState('');
  const [precipitation, setPrecipitation] = useState('');
  const [weatherIcon, setWeatherIcon] = useState();
  const [description, setDescription] = useState('');
  const [description1, setDescription1] = useState('');
  const [description2, setDescription2] = useState('');
  const [description3, setDescription3] = useState('');
  const [description4, setDescription4] = useState('');
  const [description5, setDescription5] = useState('');
  const apiKey = 'e8d7667c7d8a7910c656d1302e62f8b6';
  const [disabled, setDisabled] = useState(true);
  const [day1, setDay1] = useState('Input Location');
  const [day2, setDay2] = useState('Input Location');
  const [day3, setDay3] = useState('Input Location');
  const [day4, setDay4] = useState('Input Location');
  const [day5, setDay5] = useState('Input Location');
  const weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday", "Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  const d = new Date();
  let day = weekday[d.getDay()];
  const [city, setCity] = useState('TBD');
  const [zipCode, setZipCode] = useState('');
  const [test, setTest] = useState('');


  const getWeatherData = async () => {
    const apiUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}`;
    const response = await fetch(apiUrl);
    const data = await response.json();
    console.log(data);
    let celsiusTemp = data.list[0].main.temp - 273.15;
    let fahrenheitTemp = (celsiusTemp * 9) / 5 + 32;
    setTemp(fahrenheitTemp.toFixed(0));
    setWeatherIcon(data.list[0].weather[0].icon);
    setHumidity(data.list[0].main.humidity);
    setWindSpeed((data.list[0].wind.speed * 2.23694).toFixed(0));
    setDescription(data.list[0].weather[0].description);
    setPrecipitation(data.list[0].pop);
    setHumidity1(data.list[7].main.humidity);
    setWindSpeed1((data.list[7].wind.speed * 2.23694).toFixed(0));
    setDescription1(data.list[7].weather[0].description);
    setHumidity2(data.list[15].main.humidity);
    setWindSpeed2((data.list[15].wind.speed * 2.23694).toFixed(0));
    setDescription2(data.list[15].weather[0].description);
    setHumidity3(data.list[23].main.humidity);
    setWindSpeed3((data.list[23].wind.speed * 2.23694).toFixed(0));
    setDescription3(data.list[23].weather[0].description);
    setHumidity4(data.list[31].main.humidity);
    setWindSpeed4((data.list[31].wind.speed * 2.23694).toFixed(0));
    setDescription4(data.list[31].weather[0].description);
    setHumidity5(data.list[39].main.humidity);
    setWindSpeed5((data.list[39].wind.speed * 2.23694).toFixed(0));
    setDescription5(data.list[39].weather[0].description);
    setDisabled(false);
    setCity(data.city.name);

    let celsiusTemp2 = data.list[0].main.feels_like - 273.15;
    let fahrenheitTemp2 = (celsiusTemp2 * 9) / 5 + 32;
    setFeelsLike(fahrenheitTemp2.toFixed(0));
    
    setDay1(data.list[7].main.temp)
    let celsiusTemp3 = data.list[7].main.temp - 273.15;
    setDay1(((celsiusTemp3 * 9) / 5 + 32).toFixed(0));

    setDay2(data.list[15].main.temp)
    let celsiusTemp4 = data.list[15].main.temp - 273.15;
    setDay2(((celsiusTemp4 * 9) / 5 + 32).toFixed(0));

    setDay3(data.list[23].main.temp)
    let celsiusTemp5 = data.list[23].main.temp - 273.15;
    setDay3(((celsiusTemp5 * 9) / 5 + 32).toFixed(0));

    setDay4(data.list[31].main.temp)
    let celsiusTemp6 = data.list[31].main.temp - 273.15;
    setDay4(((celsiusTemp6 * 9) / 5 + 32).toFixed(0));

    setDay5(data.list[39].main.temp)
    let celsiusTemp7 = data.list[39].main.temp - 273.15;
    setDay5(((celsiusTemp7 * 9) / 5 + 32).toFixed(0));
  };

  const getWeatherIconUrl = (iconCode) => {
    return `http://openweathermap.org/img/w/${iconCode}.png`;
  };

  const useZipCode = async () => {
    const zipApiUrl = `https://api.openweathermap.org/data/2.5/weather?zip=${zipCode},us&appid=${apiKey}`;
    const zipResponse = await fetch(zipApiUrl);
    const zipData = await zipResponse.json();
    setLat(zipData.coord.lat.toString());
    setLon(zipData.coord.lon.toString());
    getWeatherData();
  };

  const calcMax = () => {
    
  }

  const calcMin = () => {
    
  }

  return (
    //min height to window height
    <ImageBackground source={image} style={styles.container}>
      <View style={styles.container2}>
        <View style={styles.header}>
          <View style={styles.locationStyle}>
            <Text style={styles.number}>Current Location: {city}</Text>
            <Text style={styles.number2}>{!isNaN(parseFloat(temp)) ? `${temp}° F` : 'Input Location'}</Text>
          </View>
        </View> 
        <View style={styles.icon}>
          {weatherIcon && (
            <Image
              source={{ uri: getWeatherIconUrl(weatherIcon) }}
              style={{ width: '100%', height: '100%', resizeMode: 'contain'}}
            />
          )}
        </View>
        <View style={styles.info}>
          <Text style={styles.number}>{description}</Text>
          <Text style={styles.number}>Feels Like: {!isNaN(parseFloat(feelsLike)) ? `${feelsLike}° F` : 'Input Location'}</Text>
          <Text style={styles.number}>Wind Speed: {!isNaN(parseFloat(windSpeed)) ? `${windSpeed} mph` : 'Input Location'}</Text>
          <Text style={styles.number}>Humidity: {!isNaN(parseFloat(humidity)) ? `${humidity}%` : 'Input Location'}</Text>
          <Text style={styles.number}>Precipitation: {!isNaN(parseFloat(humidity)) ? `${precipitation * 100}%` : 'Input Location'}</Text>          
        </View>
        <View style={styles.userEnter}>
          <TextInput
            style={styles.number3}
            placeholder="Enter Latitude"
            placeholderTextColor="white"
            value={lat}
            onChangeText={setLat}
            editable={!zipCode}
          />
          <TextInput
            style={styles.number3}
            placeholder="Enter Longitude"
            placeholderTextColor="white"
            value={lon}
            onChangeText={setLon}
            editable={!zipCode}
          />
          <TextInput
            style={styles.number3}
            placeholder="Enter Zip Code"
            placeholderTextColor="white"
            value={zipCode}
            onChangeText={setZipCode}
          />
          <TouchableOpacity style={styles.button} onPress={useZipCode}>
            <Text style={styles.buttonText}>Use Zip Code</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={getWeatherData}>
            <Text style={styles.buttonText}>Get Weather</Text>
          </TouchableOpacity>
        </View>
        <ScrollView style={styles.fiveDay} horizontal={true}>
          <View style={styles.fiveDayText}>
            <Text style={styles.number}>{weekday[d.getDay() + 1]}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${day1}° F` : 'Input Location'}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${description1}` : `Input Location`}</Text>
            <Text style={styles.number}>Wind Speed: {!isNaN(parseFloat(windSpeed1)) ? `${windSpeed1} mph` : 'Input Location'}</Text>
            <Text style={styles.number}>Humidity: {!isNaN(parseFloat(humidity1)) ? `${humidity1}%` : 'Input Location'}</Text>
          </View>
          <View style={styles.fiveDayText}>
            <Text style={styles.number}>{weekday[d.getDay() + 2]}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${day2}° F` : 'Input Location'}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${description2}` : `Input Location`}</Text>
            <Text style={styles.number}>Wind Speed: {!isNaN(parseFloat(windSpeed2)) ? `${windSpeed2} mph` : 'Input Location'}</Text>
            <Text style={styles.number}>Humidity: {!isNaN(parseFloat(humidity2)) ? `${humidity2}%` : 'Input Location'}</Text>
          </View>
          <View style={styles.fiveDayText}>
            <Text style={styles.number}>{weekday[d.getDay() + 3]}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${day3}° F` : 'Input Location'}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${description3}` : `Input Location`}</Text>
            <Text style={styles.number}>Wind Speed: {!isNaN(parseFloat(windSpeed3)) ? `${windSpeed3} mph` : 'Input Location'}</Text>
            <Text style={styles.number}>Humidity: {!isNaN(parseFloat(humidity3)) ? `${humidity3}%` : 'Input Location'}</Text>
          </View>
          <View style={styles.fiveDayText}>
            <Text style={styles.number}>{weekday[d.getDay() + 4]}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day4)) ? `${day5}° F` : 'Input Location'}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${description4}` : `Input Location`}</Text>
            <Text style={styles.number}>Wind Speed: {!isNaN(parseFloat(windSpeed4)) ? `${windSpeed4} mph` : 'Input Location'}</Text>
            <Text style={styles.number}>Humidity: {!isNaN(parseFloat(humidity4)) ? `${humidity4}%` : 'Input Location'}</Text>
          </View>
          <View style={styles.fiveDayText}>
            <Text style={styles.number}>{weekday[d.getDay() + 5]}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${day5}° F` : 'Input Location'}</Text>
            <Text style={styles.number}>{!isNaN(parseFloat(day5)) ? `${description5}` : `Input Location`}</Text>
            <Text style={styles.number}>Wind Speed: {!isNaN(parseFloat(windSpeed5)) ? `${windSpeed5} mph` : 'Input Location'}</Text>
            <Text style={styles.number}>Humidity: {!isNaN(parseFloat(humidity5)) ? `${humidity5}%` : 'Input Location'}</Text>
          </View>
        </ScrollView>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    resizeMode: 'cover',
  },
  container2: {
    height: windowHeight,
  },
  header: {
    width: '100%',
    height: '15%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 10,
  },
  icon: {
    height: '7%',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  number: {
    fontSize: 18,
    fontFamily: 'Courier New',
    color: 'white',
    textAlign: 'center',
  },
  number2: {
    fontSize: 30,
    fontFamily: 'Courier New',
    color: 'white',
  },
  number3: {
    fontSize: 18,
    fontFamily: 'Courier New',
    color: 'white',
    borderWidth: 1,
    margin: 5,
    padding: 5,
    borderColor: 'black',
    textAlign: 'center',
  },
  locationStyle: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    backgroundColor: 'grey',
    padding: 10,
    margin: 10,
    borderRadius: 10,
  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    textAlign: 'center',
  },
  info: {
    width: '100%',
    height: '15%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  userEnter: {
    height: '40%',
    width: '100%',
    alignItems: 'center',
  },
  fiveDay: {
    height: '40%',
    alignItems: 'center',
  },
  fiveDayText: {
    height: '100%',
    borderWidth: 2,
    borderColor: 'white',
    padding: 20,
    alignItems: 'center',
    fontWeight: 'bold',
  },
});
